# template-01 — component mapping report

## What template-01 actually is
183 mesh objects named `NNN_shapeMMM` (NNN = world node index, shapeMMM = mesh/shape datablock).
Shapes are **heavily instanced** — e.g. `shape208`×18, `shape12`×8, `shape17`×3. A shape ID alone
does **not** identify a character; the minifigs **share body-part geometry** (hips/legs/feet/torso are
the same mesh across characters). Identity therefore comes from a **whole-body rigid fit**, not from
the shape number. Every match below is confirmed by Kabsch **RMSD ≈ 0** (byte-identical geometry up to
a rigid transform), so these assignments are exact, not heuristic.

Two functional regions:
- **Minifig lineup + ground tiles** (~X 480–560, Z 1090–1315)
- **Castle build** = `oc6098-1` base + ~40 unknown "top" pieces (~X 450–600, Z 1590–1770)
- Everything else = terrain / water / walls / roads (the big `shape200–214` ground planes)

## Confirmed character → template-object mapping
Coordinates are world-space from the OBJ (note: OBJ Y is the exporter's flipped axis; +Y-up in VRT).
Full rotation matrices / quaternions are in `template01_component_map.json`.

| Component | Label | Template objects to remove | World t (x,y,z) | Euler XYZ° |
|---|---|---|---|---|
| minifigqueenleonora01 | Queen Leonora | 012,013,015,018,022,025,028,031 | (482.3, -3.2, 1314.5) | (-180, 0, 180) |
| minifigkingleo00 | King Leo | 040,043,045,047,049,050,052,055,059,062,064,067 | (559.9, -3.2, 1301.6) | (-180, 0, 180) |
| minifiggenericgood00 | Generic Good | 122,125,127,129,131,132,135,137,140,144,147,150,154,156 | (480.2, -3.2, 1091.7) | (180, 0, 180) |
| oc6098-1 | Castle base | 261,265,269,275,280,288,291,297,302,304,306,308,312,313,317,318,324,328 | (325.3, 0, 1520.5) | (0,0,0) |

King Leo's unique anchors (not shared with other figs): head `052_shape25`, weapon `L_7101500` = `055_shape27`.

## Plate: l4109610 → should be l4109612
`shape200` (8-vtx flat tile) appears **3×**, tiling the ground on a 256-unit Z grid — all should be swapped to **l4109612**:

| Template object | World center |
|---|---|
| 512_shape200 | (520.5, ~0, 882.9) |
| 520_shape200 | (520.5, ~0, 1138.9) |
| 528_shape200 | (520.5, ~0, 1394.9) |

## Note on `ocb6095b3` / `minifigleo00`
You mentioned `ocb6095b3` and `minifigleo00` as also being pulled in, but no OBJ was uploaded for
either. `minifigkingleo00` is present and mapped above; if `minifigleo00` is a different figure,
upload it and run the tool. Same for `ocb6095b3`.

## The unknown "castle-top" pieces (40 objects, 13 groups)
These stack on `oc6098-1`. They're catalogued in `castle_top_catalog.json` and drawn (labeled G0–G12)
in `castle_top_segmentation.png`. The layout is mirror-symmetric (paired turrets/wall sections), e.g.
G2↔G3 (small turrets, X≈452 vs 582), G4↔G5 (wall blocks), G10↔G11 (small symmetric decorations).
To name them precisely: **upload the component OBJs** and run the matcher — it will return their exact
template objects + transforms just like the table above.

## Reusable tool
`locate_component.py TEMPLATE.obj COMPONENT.obj [...]` → prints matched template objects + world
translation, rotation matrix, euler, quaternion, and dumps JSON. Naming-independent; geometry-based.
