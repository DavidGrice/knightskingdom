#!/usr/bin/env python3
"""
locate_component.py  --  match a standalone component OBJ against a template OBJ,
recover which template objects it corresponds to, and the world transform.

Usage:
    python3 locate_component.py TEMPLATE.obj COMPONENT.obj [COMPONENT2.obj ...]

Prints, per component:
  - how many of its parts were located in the template (should be all)
  - the template object names it maps to (the ones to REMOVE from the map)
  - world translation t, rotation matrix R, euler XYZ (deg), quaternion
Works regardless of naming, because matching is by rotation/translation-invariant
geometry (vertex count + covariance signature) and confirmed by Kabsch RMSD.
"""
import sys, re, json
import numpy as np
from collections import defaultdict

def parse_obj(path):
    objs=[]; cur=None; all_v=[]
    def flush():
        nonlocal cur
        if cur and cur['vidx']:
            idx=sorted(cur['vidx']); remap={g:i for i,g in enumerate(idx)}
            V=np.array([all_v[g-1] for g in idx],float)
            objs.append(dict(name=cur['name'],v=V))
        cur=None
    for line in open(path,'r',errors='replace'):
        t=line.split()
        if not t: continue
        if t[0]=='v': all_v.append([float(x) for x in t[1:4]])
        elif t[0] in ('o','g'): flush(); cur=dict(name=line[2:].strip(),vidx=set())
        elif t[0]=='f':
            if cur is None: cur=dict(name='__root__',vidx=set())
            for tok in t[1:]:
                gi=int(tok.split('/')[0]); gi=len(all_v)+1+gi if gi<0 else gi
                cur['vidx'].add(gi)
    flush(); return objs

def kabsch(P,Q):
    cP=P.mean(0);cQ=Q.mean(0);A=P-cP;B=Q-cQ
    U,S,Vt=np.linalg.svd(A.T@B); d=np.sign(np.linalg.det(Vt.T@U.T))
    R=Vt.T@np.diag([1,1,d])@U.T; t=cQ-R@cP
    return R,t,np.sqrt(((B-A@R.T)**2).sum(1).mean())

def euler_xyz(R):
    sy=np.sqrt(R[0,0]**2+R[1,0]**2)
    if sy>1e-6: x=np.arctan2(R[2,1],R[2,2]);y=np.arctan2(-R[2,0],sy);z=np.arctan2(R[1,0],R[0,0])
    else: x=np.arctan2(-R[1,2],R[1,1]);y=np.arctan2(-R[2,0],sy);z=0
    return np.degrees([x,y,z])

def quat(R):
    w=np.sqrt(max(0,1+np.trace(R)))/2; 
    x=(R[2,1]-R[1,2])/(4*w); y=(R[0,2]-R[2,0])/(4*w); z=(R[1,0]-R[0,1])/(4*w)
    return [x,y,z,w]

def obj_index(n):
    m=re.match(r'(\d+)_',n); return int(m.group(1)) if m else 0

def main():
    if len(sys.argv)<3:
        print(__doc__); sys.exit(1)
    tmpl=parse_obj(sys.argv[1])
    by_nv=defaultdict(list)
    for i,o in enumerate(tmpl): by_nv[len(o['v'])].append(i)
    tcent=[o['v'].mean(0) for o in tmpl]
    out=[]
    for comp_path in sys.argv[2:]:
        comp=parse_obj(comp_path)
        parts=[(c['name'],c['v'],len(c['v'])) for c in comp]
        anchor=min(range(len(parts)),key=lambda i:len(by_nv[parts[i][2]]))
        aname,aV,anv=parts[anchor]; best=None
        for ti in by_nv[anv]:
            R,t,rmsd=kabsch(aV,tmpl[ti]['v'])
            if rmsd>0.5: continue
            matched=[]; used=set()
            for pn,pV,pnv in parts:
                pctr=(pV@R.T+t).mean(0); cand=None
                for tj in by_nv[pnv]:
                    if tj in used or np.linalg.norm(tcent[tj]-pctr)>2.0: continue
                    if kabsch(pV,tmpl[tj]['v'])[2]<0.5: cand=tj; break
                if cand is not None: used.add(cand); matched.append((pn,tmpl[cand]['name']))
            if best is None or len(matched)>best[0]: best=(len(matched),ti,R,t,matched)
        score,ti,R,t,matched=best
        rec=dict(component=comp_path, parts=len(parts), matched=score,
                 world_translation=[round(float(x),3) for x in t],
                 rotation_matrix=[[round(float(v),5) for v in r] for r in R],
                 euler_xyz_deg=[round(float(v),2) for v in euler_xyz(R)],
                 quaternion_xyzw=[round(float(v),5) for v in quat(R)],
                 template_objects=sorted((tn for _,tn in matched),key=obj_index))
        out.append(rec)
        print(f"\n{comp_path}: {score}/{len(parts)} parts located")
        print(f"  t={rec['world_translation']}  eulerXYZ={rec['euler_xyz_deg']}")
        print("  template objects to remove: "+", ".join(rec['template_objects']))
    print("\n---JSON---")
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
